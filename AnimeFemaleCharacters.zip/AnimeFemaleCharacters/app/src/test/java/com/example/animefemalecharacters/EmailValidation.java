package com.example.animefemalecharacters;

public class EmailValidation {
}
