package com.example.animefemalecharacters;

import android.graphics.Bitmap;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class AnimeGirl {

    private String nome;
    private String obra;

    @PrimaryKey
    private int id;

    private String hairColor;

    private Bitmap photo;

    public AnimeGirl(String nome, String obra, int id, String hairColor, Bitmap photo) {
        this.nome = nome;
        this.obra = obra;
        this.id = id;
        this.hairColor = hairColor;
        this.photo = photo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getObra() {
        return obra;
    }

    public void setObra(String obra) {
        this.obra = obra;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getHairColor() {
        return hairColor;
    }

    public void setHairColor(String hairColor) {
        this.hairColor = hairColor;
    }

    public Bitmap getPhoto() {
        return photo;
    }

    public void setPhoto(Bitmap photo) {
        this.photo = photo;
    }

}
