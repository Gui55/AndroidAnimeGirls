package com.example.animefemalecharacters.users;

import android.graphics.Bitmap;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface UserDAO {

    @Insert
    public void insert(User... users);

    @Query("SELECT * FROM user")
    public List<User> getUsuarios();

    @Query("SELECT COUNT(*) FROM user WHERE username LIKE :nUsername")
    public int seHa(String nUsername);

    @Query("SELECT COUNT(*) FROM user WHERE username LIKE :nUsername AND senha LIKE :nSenha")
    public int existeUserComEssaSenha(String nUsername, String nSenha);

    @Query("SELECT foto FROM user WHERE username LIKE :nUsername")
    public Bitmap getFoto(String nUsername);

}
