package com.example.animefemalecharacters.users;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.service.autofill.UserData;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.animefemalecharacters.R;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static android.app.Activity.RESULT_OK;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link CadastroFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link CadastroFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CadastroFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private EditText userName, email, senha, confSenha;

    private ImageButton btnTirarFoto, btnVoltar, btnCadastrar;

    private ImageView imagemSelecionada;

    private AlertDialog alertDialog;
    private AlertDialog.Builder builder;

    private Uri uri;

    private OnFragmentInteractionListener mListener;

    static final int REQUEST_IMAGE_CAPTURE = 1;
    static final int REQUEST_ACTION_PICK = 2;

    public CadastroFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CadastroFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static CadastroFragment newInstance(String param1, String param2) {
        CadastroFragment fragment = new CadastroFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        final ViewGroup root = (ViewGroup)inflater.inflate(R.layout.fragment_cadastro, container, false);

        //Configurações do AlertDialog

        //Instância, Título e Mensagem
        builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Título");
        builder.setMessage("Por onde você quer pegar a foto?");

        //"Botão positivo"
        builder.setPositiveButton("Selecionar do Celular", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intentA = new Intent(Intent.ACTION_PICK);

                intentA.setType("image/*");

                startActivityForResult(intentA, REQUEST_ACTION_PICK);
            }
        });

        //"Botão negativo"
        builder.setNegativeButton("Usar a câmera", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intentB = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                if(intentB.resolveActivity(getActivity().getPackageManager())!=null){
                    startActivityForResult(intentB, REQUEST_IMAGE_CAPTURE);
                }
            }
        });

        //Criação do AlertDialog
        alertDialog = builder.create();

        //Associação dos EditTexts e a ImageView
        userName = root.findViewById(R.id.cadastroUsername);
        email = root.findViewById(R.id.cadastroEmail);
        senha = root.findViewById(R.id.cadastroSenha);
        confSenha = root.findViewById(R.id.confirmacaoSenha);
        imagemSelecionada = root.findViewById(R.id.photo);

        //Associação dos Buttons
        btnTirarFoto = root.findViewById(R.id.btnTirarFoto);
        btnCadastrar = root.findViewById(R.id.btnCriarUsuario);
        btnVoltar = root.findViewById(R.id.btnVoltar);

        //Fazer com que os EditTexts da senha exibam pontos no lugar de letras
        senha.setTransformationMethod(new PasswordTransformationMethod());
        confSenha.setTransformationMethod(new PasswordTransformationMethod());

        //Escutador do botão de voltar
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getFragmentManager().beginTransaction().replace(R.id.frameContainer, new LoginFragment()).commit();
            }
        });

        //Escutador do botão de cadastro
        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Se nenhum EditText estiver vazio
                if(!userName.getText().toString().equals("") &&
                        !email.getText().toString().equals("") &&
                        !senha.getText().toString().equals("") &&
                        !confSenha.getText().toString().equals("")){

                    //Se a senha e a confirmação da senha baterem
                    if(senha.getText().toString().equals(confSenha.getText().toString())){

                        if(!android.util.Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()){

                            Toast.makeText(getView().getContext(), "E-mail inválido", Toast.LENGTH_SHORT).show();

                        } else { //Se tudo estiver certo

                            UserDatabase.getUserDatabase(getView().getContext()).userDAO().insert(

                                    new User(userName.getText().toString(),
                                            email.getText().toString(),
                                            senha.getText().toString(),
                                            ((BitmapDrawable)imagemSelecionada.getDrawable()).getBitmap())
                            );

                        }

                    } else { // Se não baterem

                        Toast.makeText(getView().getContext(), "As senhas não batem", Toast.LENGTH_SHORT).show();

                    }

                } else{

                    Toast.makeText(getView().getContext(), "Faltam dados", Toast.LENGTH_SHORT)
                            .show();

                }

            }
        });

        //Escutador do botão de tirar foto
        btnTirarFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                alertDialog.show();

            }
        });

        return root;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_IMAGE_CAPTURE && resultCode==RESULT_OK){

            imagemSelecionada.setImageBitmap((Bitmap)data.getExtras().get("data"));

        } else if(requestCode == REQUEST_ACTION_PICK){

            uri = data.getData();

            Bitmap im = null;

            try{

                im = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), uri);
                imagemSelecionada.setImageBitmap(im);

            }catch (Exception e){

                e.printStackTrace();

            }

        }
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {

        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
