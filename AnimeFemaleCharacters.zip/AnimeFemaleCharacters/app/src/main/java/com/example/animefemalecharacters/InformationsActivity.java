package com.example.animefemalecharacters;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.animefemalecharacters.dandere.DandereFragment;
import com.example.animefemalecharacters.deredere.DeredereFragment;
import com.example.animefemalecharacters.kuudere.KuudereFragment;
import com.example.animefemalecharacters.others.OthersFragment;
import com.example.animefemalecharacters.tsundere.TsudereFragment;
import com.example.animefemalecharacters.yandere.YandereFragment;

import java.io.IOException;
import java.util.Random;

public class InformationsActivity extends AppCompatActivity {

    int id;

    TextView title, description;

    ImageView photo;

    private MediaPlayer mediaPlayer;

    Random random;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informations);

        //Pegar dados passados por um dos fragments com lista

        Intent intent = getIntent();

        //Pegar o id
        int extra = (int) intent.getSerializableExtra("oId");


        //Associar os TextViews
        title = (TextView)findViewById(R.id.textNome);
        description = (TextView)findViewById(R.id.description);
        photo = (ImageView)findViewById(R.id.photo);

        Log.d("TheId", String.valueOf(extra));

        //Configuração do MediaPlayer

        mediaPlayer = new MediaPlayer();

        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                mediaPlayer.start();
            }
        });

        int r;

        try {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.reset();
            AssetFileDescriptor afd = null;

            switch (extra){
                case 0://Corrigido

                    random = new Random();

                    r = random.nextInt(4);

                    Log.d("rDeb", String.valueOf(r));

                    if(r==0){
                        afd = getResources().openRawResourceFd(R.raw.nagisa_song);
                        break;
                    } else if(r==1){
                        afd = getResources().openRawResourceFd(R.raw.the_place_where_wishes_come_true_ii);
                        break;
                    } else if(r==2){
                        afd = getResources().openRawResourceFd(R.raw.roaring_tides);
                        break;
                    } else if(r==3){
                        afd = getResources().openRawResourceFd(R.raw.roaring_tides_ii);
                        break;
                    }

                    
                case 1://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.bouken_desho_desho);
                    break;

                case 2://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.sadness_and_sorrow);
                    break;

                case 3://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.forever_we_can_make_it);
                    break;

                case 4://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.minori_chihara);
                    break;

                case 5://Corigido
                    afd = getResources().openRawResourceFd(R.raw.girly_air_force_song);
                    break;

                case 6://Coriigido

                    random = new Random();

                    r = random.nextInt(3);

                    if(r==0){
                        afd = getResources().openRawResourceFd(R.raw.the_place_where_wishes_come_true_ii);
                        break;
                    } else if(r==1){
                        afd = getResources().openRawResourceFd(R.raw.roaring_tides);
                        break;
                    } else if(r==2){
                        afd = getResources().openRawResourceFd(R.raw.roaring_tides_ii);
                        break;
                    }


                case 7://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.unjust_life);
                    break;

                case 8://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.a_cruel_angels_thesis);
                    break;

                case 9://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.futari_no_honey_boy);
                    break;

                case 10://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.chain_of_memories);
                    break;

                case 11://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.futari_no_honey_boy);
                    break;

                case 12://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.super_scription_of_data);
                    break;

                case 13://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.fsn_op);
                    break;

                case 14://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.a_cruel_angels_thesis);
                    break;

                case 15://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.bouken_desho_desho);
                    break;

                case 16://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.kimi_no_sei_peggies);
                    break;

                case 17://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.forever_we_can_make_it);
                    break;

                case 18://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.mirai_nikki);
                    break;

                case 19://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.hsl_op);
                    break;

                case 20://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.super_scription_of_data);
                    break;

                case 21://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.sd_op);
                    break;

                case 22://Corrigido
                    afd = getResources().openRawResourceFd(R.raw.el_lilium);
                    break;

            }


            if (afd != null) {
                mediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                mediaPlayer.prepareAsync();
            }
        } catch (IOException e) {
            Log.e("", e.getMessage());
        }


        //Configurar os dados das personagens
        switch (extra){

            case 0:
                title.setText(DandereFragment.danderes.get(extra).getNome());
                photo.setImageBitmap(DandereFragment.danderes.get(extra).getPhoto());
                description.setText(R.string.nagisa);
                Log.d("Should", DandereFragment.danderes.get(extra).getNome());
                break;

            case 1:
                title.setText(DandereFragment.danderes.get(extra).getNome());
                photo.setImageBitmap(DandereFragment.danderes.get(extra).getPhoto());
                description.setText(R.string.mikuru);
                Log.d("Should", DandereFragment.danderes.get(extra).getNome());
                break;

            case 2:
                title.setText(DandereFragment.danderes.get(extra).getNome());
                photo.setImageBitmap(DandereFragment.danderes.get(extra).getPhoto());
                description.setText(R.string.hinata);
                Log.d("Should", DandereFragment.danderes.get(extra).getNome());
                break;

            case 3:
                title.setText(DeredereFragment.derederes.get(0).getNome());
                photo.setImageBitmap(DeredereFragment.derederes.get(0).getPhoto());
                description.setText(R.string.lala);
                Log.d("Should", DeredereFragment.derederes.get(0).getNome());
                break;

            case 4:
                title.setText(KuudereFragment.kuuderes.get(0).getNome());
                photo.setImageBitmap(KuudereFragment.kuuderes.get(0).getPhoto());
                description.setText(R.string.violet);
                Log.d("Should", KuudereFragment.kuuderes.get(0).getNome());
                break;

            case 5:
                title.setText(KuudereFragment.kuuderes.get(1).getNome());
                photo.setImageBitmap(KuudereFragment.kuuderes.get(1).getPhoto());
                description.setText(R.string.gripen);
                Log.d("Should", KuudereFragment.kuuderes.get(1).getNome());
                break;

            case 6:
                title.setText(KuudereFragment.kuuderes.get(2).getNome());
                photo.setImageBitmap(KuudereFragment.kuuderes.get(2).getPhoto());
                description.setText(R.string.tomoyo);
                Log.d("Should", KuudereFragment.kuuderes.get(2).getNome());
                break;

            case 7:
                title.setText(KuudereFragment.kuuderes.get(3).getNome());
                photo.setImageBitmap(KuudereFragment.kuuderes.get(3).getPhoto());
                description.setText(R.string.kanade);
                Log.d("Should", KuudereFragment.kuuderes.get(3).getNome());
                break;

            case 8:
                title.setText(KuudereFragment.kuuderes.get(4).getNome());
                photo.setImageBitmap(KuudereFragment.kuuderes.get(4).getPhoto());
                description.setText(R.string.rei);
                Log.d("Should", KuudereFragment.kuuderes.get(4).getNome());
                break;

            case 9:
                title.setText(KuudereFragment.kuuderes.get(5).getNome());
                photo.setImageBitmap(KuudereFragment.kuuderes.get(5).getPhoto());
                description.setText(R.string.riko);
                Log.d("Should", KuudereFragment.kuuderes.get(5).getNome());
                break;

            case 10:
                title.setText(OthersFragment.others.get(0).getNome());
                photo.setImageBitmap(OthersFragment.others.get(0).getPhoto());
                description.setText(R.string.emilia);
                Log.d("Should", OthersFragment.others.get(0).getNome());
                break;

            case 11:
                title.setText(OthersFragment.others.get(1).getNome());
                photo.setImageBitmap(OthersFragment.others.get(1).getPhoto());
                description.setText(R.string.ako);
                Log.d("Should", OthersFragment.others.get(1).getNome());
                break;

            case 12:
                title.setText(OthersFragment.others.get(2).getNome());
                photo.setImageBitmap(OthersFragment.others.get(2).getPhoto());
                description.setText(R.string.rena);
                Log.d("Should", OthersFragment.others.get(2).getNome());
                break;

            case 13:
                title.setText(TsudereFragment.tsunderes.get(0).getNome());
                photo.setImageBitmap(TsudereFragment.tsunderes.get(0).getPhoto());
                description.setText(R.string.rin);
                Log.d("Should", TsudereFragment.tsunderes.get(0).getNome());
                break;

            case 14:
                title.setText(TsudereFragment.tsunderes.get(1).getNome());
                photo.setImageBitmap(TsudereFragment.tsunderes.get(1).getPhoto());
                description.setText(R.string.asuka);
                Log.d("Should", TsudereFragment.tsunderes.get(1).getNome());
                break;

            case 15:
                title.setText(TsudereFragment.tsunderes.get(2).getNome());
                photo.setImageBitmap(TsudereFragment.tsunderes.get(2).getPhoto());
                description.setText(R.string.haruhi);
                Log.d("Should", TsudereFragment.tsunderes.get(2).getNome());
                break;

            case 16:
                title.setText(TsudereFragment.tsunderes.get(3).getNome());
                photo.setImageBitmap(TsudereFragment.tsunderes.get(3).getPhoto());
                description.setText(R.string.mai);
                Log.d("Should", TsudereFragment.tsunderes.get(3).getNome());
                break;

            case 17:
                title.setText(TsudereFragment.tsunderes.get(4).getNome());
                photo.setImageBitmap(TsudereFragment.tsunderes.get(4).getPhoto());
                description.setText(R.string.yui);
                Log.d("Should", TsudereFragment.tsunderes.get(4).getNome());
                break;

            case 18:
                title.setText(YandereFragment.yanderes.get(0).getNome());
                photo.setImageBitmap(YandereFragment.yanderes.get(0).getPhoto());
                description.setText(R.string.yuno);
                Log.d("Should", YandereFragment.yanderes.get(0).getNome());
                break;

            case 19:
                title.setText(YandereFragment.yanderes.get(1).getNome());
                photo.setImageBitmap(YandereFragment.yanderes.get(1).getPhoto());
                description.setText(R.string.satou);
                Log.d("Should", YandereFragment.yanderes.get(1).getNome());
                break;

            case 20:
                title.setText(YandereFragment.yanderes.get(2).getNome());
                photo.setImageBitmap(YandereFragment.yanderes.get(2).getPhoto());
                description.setText(R.string.shion);
                Log.d("Should", YandereFragment.yanderes.get(2).getNome());
                break;

            case 21:
                title.setText(YandereFragment.yanderes.get(3).getNome());
                photo.setImageBitmap(YandereFragment.yanderes.get(3).getPhoto());
                description.setText(R.string.katsura);
                Log.d("Should", YandereFragment.yanderes.get(3).getNome());
                break;

            case 22:
                title.setText(YandereFragment.yanderes.get(4).getNome());
                photo.setImageBitmap(YandereFragment.yanderes.get(4).getPhoto());
                description.setText(R.string.lucy);
                Log.d("Should", YandereFragment.yanderes.get(4).getNome());
                break;


        }

    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
        }
        mediaPlayer.release();

        finish();
    }
}
