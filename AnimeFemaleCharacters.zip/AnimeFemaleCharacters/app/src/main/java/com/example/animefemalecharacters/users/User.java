package com.example.animefemalecharacters.users;

import android.graphics.Bitmap;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class User {

    @PrimaryKey(autoGenerate = true)
    int id;

    String username;
    String email;
    String senha;

    Bitmap foto;

}
