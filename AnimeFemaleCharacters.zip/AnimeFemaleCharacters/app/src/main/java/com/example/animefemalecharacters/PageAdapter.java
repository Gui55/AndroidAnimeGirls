package com.example.animefemalecharacters;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.animefemalecharacters.dandere.DandereFragment;
import com.example.animefemalecharacters.deredere.DeredereFragment;
import com.example.animefemalecharacters.kuudere.KuudereFragment;
import com.example.animefemalecharacters.others.OthersFragment;
import com.example.animefemalecharacters.tsundere.TsudereFragment;
import com.example.animefemalecharacters.yandere.YandereFragment;

public class PageAdapter extends FragmentPagerAdapter {

    public PageAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new YandereFragment();
            case 1:
                return new TsudereFragment();
            case 2:
                return new KuudereFragment();
            case 3:
                return new DandereFragment();
            case 4:
                return new DeredereFragment();
            case 5:
                return new OthersFragment();
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return 6;
    }

}
