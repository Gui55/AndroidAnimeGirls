package com.example.animefemalecharacters.kuudere;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.animefemalecharacters.AnimeGirl;
import com.example.animefemalecharacters.AnimeGirlAdapter;
import com.example.animefemalecharacters.InformationsActivity;
import com.example.animefemalecharacters.R;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link KuudereFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link KuudereFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class KuudereFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public static List<AnimeGirl> kuuderes = new ArrayList<AnimeGirl>();
    private RecyclerView recyclerView;

    public KuudereFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment KuudereFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static KuudereFragment newInstance(String param1, String param2) {
        KuudereFragment fragment = new KuudereFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        if(kuuderes.size()==0) {

            kuuderes.add(new AnimeGirl("Violet Evergarden", "Violet Evergarden", 4, "loiro",
                    BitmapFactory.decodeResource(getResources(), R.drawable.violet_evergarden)));

            kuuderes.add(new AnimeGirl("Gripen", "Girly Air Force", 5, "rosa",
                    BitmapFactory.decodeResource(getResources(), R.drawable.gripen)));

            kuuderes.add(new AnimeGirl("Sakagami Tomoyo", "Clannad", 6, "cinza",
                    BitmapFactory.decodeResource(getResources(), R.drawable.tomoyo)));

            kuuderes.add(new AnimeGirl("Kanade Tachibana", "Angel Beats", 7, "cinza azulado",
                    BitmapFactory.decodeResource(getResources(), R.drawable.kanade)));

            kuuderes.add(new AnimeGirl("Rei Anayami", "Neon Genesis Evangelion", 8, "azul",
                    BitmapFactory.decodeResource(getResources(), R.drawable.rei)));

            kuuderes.add(new AnimeGirl("Riko Suminoe", "Kiss X Sis", 9, "castanho",
                    BitmapFactory.decodeResource(getResources(), R.drawable.riko)));

        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_dandere, container, false);

        recyclerView = (RecyclerView)rootView.findViewById(R.id.dandereRecycle);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        recyclerView.setAdapter(new AnimeGirlAdapter(kuuderes, getContext(), new AnimeGirlAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(AnimeGirl animeGirl) {
                Intent intent = new Intent(getView().getContext(), InformationsActivity.class);
                intent.putExtra("oId", animeGirl.getId());
                Log.d("idPassed", String.valueOf(animeGirl.getId()));
                startActivity(intent);
            }
        }));

        //TabsActivity.animeGirlDAO.insertList(kuuderes);


        // Inflate the layout for this fragment
        return rootView;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {

        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
