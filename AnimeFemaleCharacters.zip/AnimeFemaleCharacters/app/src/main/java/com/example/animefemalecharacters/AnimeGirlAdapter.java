package com.example.animefemalecharacters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AnimeGirlAdapter extends RecyclerView.Adapter<AnimeGirlAdapter.AnimeViewHolder> {

    private List<AnimeGirl> animeGirls;
    private Context context;
    private final OnItemClickListener onItemClickListener;

    public AnimeGirlAdapter(List<AnimeGirl> animeGirls, Context context, OnItemClickListener onItemClickListener) {
        this.animeGirls = animeGirls;
        this.context = context;
        this.onItemClickListener = onItemClickListener;
    }

    public interface OnItemClickListener {
        void onItemClick(AnimeGirl animeGirl);
    }


    @NonNull
    @Override
    public AnimeGirlAdapter.AnimeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new AnimeViewHolder(LayoutInflater.from(context).inflate(R.layout.linha_recycle, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull AnimeGirlAdapter.AnimeViewHolder holder, int position) {

        AnimeGirl animeGirl = animeGirls.get(position);

        holder.bind(animeGirl, onItemClickListener);

        holder.nome.setText(animeGirl.getNome());
        holder.obra.setText(animeGirl.getObra());
        holder.id.setText(String.valueOf(animeGirl.getId()));
        holder.hairColor.setText("Cabelo "+animeGirl.getHairColor());

        holder.girlImage.setImageBitmap(animeGirl.getPhoto());

    }

    @Override
    public int getItemCount() {
        return animeGirls.size();
    }

    protected class AnimeViewHolder extends RecyclerView.ViewHolder {

        TextView nome, obra, id, hairColor;

        ImageView girlImage;

        public AnimeViewHolder(@NonNull View itemView) {
            super(itemView);

            nome=(TextView)itemView.findViewById(R.id.recycleNome);
            obra=(TextView)itemView.findViewById(R.id.recycleObra);
            id=(TextView)itemView.findViewById(R.id.recycleId);
            hairColor=(TextView)itemView.findViewById(R.id.recycleHairColor);

            girlImage=(ImageView)itemView.findViewById(R.id.recycleImage);

        }

        public void bind(final AnimeGirl animeGirl, final OnItemClickListener onItemClickListener) {

            itemView.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {

                    onItemClickListener.onItemClick(animeGirl);

                }
            });

        }
    }
}
