package com.example.animefemalecharacters.users;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.example.animefemalecharacters.R;

public class UserActivity extends AppCompatActivity {

    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;
    LoginFragment loginFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        //Configurando o Fragment Manager e o FragmentTransaction
        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();

        //Objeto da Login Fragment
        loginFragment = new LoginFragment();

        //Fixar o Login Fragment na tela dessa activity
        fragmentTransaction.replace(R.id.frameContainer, loginFragment);
        fragmentTransaction.commit();
    }
}
